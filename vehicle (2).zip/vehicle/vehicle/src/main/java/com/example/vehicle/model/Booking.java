package com.example.vehicle.model;

import java.time.LocalDate;

public class Booking {
    private Long id;
    private String customerName;
    private String vehicleModel;
    private String registrationNumber;
    private String serviceType;
    private LocalDate preferredDate;

    // Constructors
    public Booking() {}

    public Booking(Long id, String customerName, String vehicleModel, String registrationNumber, String serviceType, LocalDate preferredDate) {
        this.id = id;
        this.customerName = customerName;
        this.vehicleModel = vehicleModel;
        this.registrationNumber = registrationNumber;
        this.serviceType = serviceType;
        this.preferredDate = preferredDate;
    }

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public String getVehicleModel() { return vehicleModel; }
    public void setVehicleModel(String vehicleModel) { this.vehicleModel = vehicleModel; }

    public String getRegistrationNumber() { return registrationNumber; }
    public void setRegistrationNumber(String registrationNumber) { this.registrationNumber = registrationNumber; }

    public String getServiceType() { return serviceType; }
    public void setServiceType(String serviceType) { this.serviceType = serviceType; }

    public LocalDate getPreferredDate() { return preferredDate; }
    public void setPreferredDate(LocalDate preferredDate) { this.preferredDate = preferredDate; }
}
