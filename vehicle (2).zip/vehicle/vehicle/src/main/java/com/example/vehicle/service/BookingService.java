package com.example.vehicle.service;

import com.example.vehicle.model.Booking;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class BookingService {

    private final List<Booking> bookings = new ArrayList<>();
    private Long idCounter = 1L;

    // Create a new booking
    public Booking createBooking(Booking booking) {
        booking.setId(idCounter++);
        bookings.add(booking);
        return booking;
    }

    // Retrieve all bookings
    public List<Booking> getAllBookings() {
        return new ArrayList<>(bookings);
    }

    // Retrieve a booking by ID
    public Optional<Booking> getBookingById(Long id) {
        return bookings.stream().filter(b -> b.getId().equals(id)).findFirst();
    }

    // Update a booking
    public Booking updateBooking(Long id, Booking updatedBooking) {
        Optional<Booking> existingBooking = getBookingById(id);
        if (existingBooking.isPresent()) {
            Booking booking = existingBooking.get();
            booking.setVehicleModel(updatedBooking.getVehicleModel());
            booking.setRegistrationNumber(updatedBooking.getRegistrationNumber());
            booking.setServiceType(updatedBooking.getServiceType());
            booking.setPreferredDate(updatedBooking.getPreferredDate());
            return booking;
        }
        return null;
    }

    // Delete a booking
    public boolean deleteBooking(Long id) {
        return bookings.removeIf(b -> b.getId().equals(id));
    }
}
